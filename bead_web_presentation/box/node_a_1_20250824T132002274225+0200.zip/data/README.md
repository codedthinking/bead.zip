Starting node called node_a_1.
No inputs in input folder. 

The raw data is in output folder is updated.
The bead meta is changed. 

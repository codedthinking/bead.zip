Starting node called node_a_2
No inputs in input folder. 

The raw data call it data_2 is in the output folder.

This is my code to work with input data and create new output.

My new output is ready with my code in code.py using node_a_1 latest version.
The bead has inputs. 

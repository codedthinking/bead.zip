This is my code to work with input data node_a updated data and create new output.

My new output is ready with my code in code.py using node_a_1 latest and node_a_2. 
The bead has inputs.
A different project. 
Not connected with node_a_1, node_a_2, node_b_1 or node_b_2.
